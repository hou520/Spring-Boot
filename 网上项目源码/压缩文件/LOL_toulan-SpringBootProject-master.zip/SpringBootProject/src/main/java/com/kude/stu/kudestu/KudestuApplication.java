package com.kude.stu.kudestu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KudestuApplication {

    public static void main(String[] args) {
        SpringApplication.run(KudestuApplication.class, args);
    }

}
